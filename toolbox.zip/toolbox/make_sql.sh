 python3 ./DMgtProject/CreditMe/manage.py sqlmigrate webapp $1
