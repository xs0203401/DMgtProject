mysql --host=35.193.119.93 --user=root --password
