python3 ./DMgtProject/CreditMe/manage.py shell
