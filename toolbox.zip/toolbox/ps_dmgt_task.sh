ps auxw | grep DMgt
