cd DMgtProject/ && git pull && sleep 0.6 && git pull && sleep 0.6 && git pull && cd ../
